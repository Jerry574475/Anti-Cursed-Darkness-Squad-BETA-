![GitHub Logo](https://raw.githubusercontent.com/Z3NTL3/Anti-Cursed-Darkness-Squad-BETA/main/putty.png)<br>
# Anti-Cursed-Darkness-Squad v7
Powerful Layer 7 & 4 panel. 
 
Thanks to MHProDev, Leeon123, R00tS3c, emp001, cocorisss  and wachirachoomsiri for their methods. This tool is an one-in-all DDOS Panel with the best methods. Only the panel it self, functionality, the proxy-crawler is coded by z3ntl3 root. Others are not part of our code!
 
<p> NOTICE: When proxies banned, then renew it by "proxy-crawl" command.</p>
<br><p>We are not responsable for what u do with this tool.

# Proofs
<p> Cracked.to Downed: https://vimeo.com/574405317</p>
<p> Zap Hosting Downed: https://www.youtube.com/watch?v=66gz6YlZDws</p>
<p> Rip Stresser Downed: https://www.youtube.com/watch?v=ydAghgWiS2I </p>
<p> iWantCheats.net Downed: https://www.youtube.com/watch?v=KWBv-ot9weE</p>
<p> NoviHacks.com Downed: https://www.youtube.com/watch?v=uda7CWAWQlU</p>
<p> WallHax.com Downed: https://www.youtube.com/watch?v=GSK_YLIsfpU</p>
<p> Hetzner GmbH Server Downed: https://www.youtube.com/watch?v=qzBAXuP7f9I&lc=UgxOhjlE0eg5iyksQ4V4AaABAg
<p> Atom Stresser Downed: https://www.youtube.com/watch?v=UyQ_hEFnsBg</p>
<p> Dos Ninja Stresser Downed: https://www.youtube.com/watch?v=_BPUP68Xqag</p>
<p> Spy Hackerz Downed: https://www.youtube.com/watch?v=YsrAGwlnM4U</p>
<p> Turk Hack Team Downed: https://www.youtube.com/watch?v=pqlYKMa0Q5I</p>

# Methods
![image](https://user-images.githubusercontent.com/48758770/125307020-fba82180-e32f-11eb-84a9-60cd852aacc1.png)
<br><br>
Thanks to MHProDev, Leeon123, R00tS3c, emp001, cocorisss  and wachirachoomsiri for their methods. This tool is an one-in-all DDOS Panel with the best methods. Only the panel it self, and the functionality is coded by z3ntl3 root. Others are not part of our code!

# Installation
```
git clone https://github.com/Z3NTL3/Anti-Cursed-Darkness-Squad-BETA && cd Anti-Cursed-Darkness-Squad-BETA/ && unzip Darkness.zip && ulimit -n 999999 && ulimit -n 999999 && ulimit -n 999999 && ulimit -n 999999 && ulimit -n 999999 && ulimit -n 999999 && python3 installer.py 
```

# Updates
https://scorpion-hackz.com/acds/update-log.txt

# Feauture Update
Darkness v8

- Proxy API will be increased by +200%, up to 4 APIs from 2.

- New licensing

- Will be never down again because of downtime Proxy APIs

- Very powerful method-combiner trick "atom-vip" 200k RQPS  for 24+ hours attack

- Design change (maybe in Darkness v8 or v8.5)

- Custom proxy mode support

New ideas we realised and we are going to add

- New design in any method run

- Animated ASCII

- General design changes

- Speeding up the load speed

- Hiding the outputs

- Method combiner 4x

- Methods will be in  /methods folder

- On Darkness V9 you can add your own method via our DATABASE Connection and make it save in your own darkness and run it easly
