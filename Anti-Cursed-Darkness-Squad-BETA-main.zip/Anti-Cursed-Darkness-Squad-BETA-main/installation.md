# Installation
```
git clone https://github.com/Z3NTL3/Anti-Cursed-Darkness-Squad-BETA && cd Anti-Cursed-Darkness-Squad-BETA/ && unzip Darkness.zip && ulimit -n 999999 && ulimit -n 999999 && ulimit -n 999999 && ulimit -n 999999 && ulimit -n 999999 && ulimit -n 999999 && python3 installer.py 
```
